# index_archive.py
# This script is responsible for building and updating the Whoosh search index
# for the local file archive. It should be run periodically (e.g., via a scheduled task)
# to ensure the search index is up-to-date with the files in the ARCHIVE_ROOT.

# --- Standard Library Imports ---
import os
import datetime
import logging
# shutil and tempfile are no longer needed as files are not copied locally.

# --- Third-party Library Imports ---
from whoosh.index import open_dir, create_in, exists_in
from whoosh.fields import Schema, TEXT, ID, DATETIME, STORED, NUMERIC
from whoosh.analysis import RegexTokenizer, LowercaseFilter # For custom analyzer

# --- Application-specific Imports ---
# Import configuration settings from 'config.py'.
# These variables define paths and application-specific names.
from config import ARCHIVE_ROOT, WHOOSH_INDEX_DIR

# --- Logging Setup ---
# Configures logging for this script.
logging.basicConfig(level=logging.INFO, # Set logging level to INFO for normal operation, use DEBUG for verbose troubleshooting
                    format='%(asctime)s - %(levelname)s - %(message)s',
                    handlers=[
                        logging.FileHandler(os.path.join(os.path.dirname(__file__), 'indexer.log')), # Logs to 'indexer.log'
                        logging.StreamHandler() # Also outputs logs to the console
                    ])

# --- Whoosh Schema Definition ---
my_simple_filename_analyzer = RegexTokenizer(r"\w+") | LowercaseFilter()

archive_schema = Schema(
    filename=TEXT(stored=True, analyzer=my_simple_filename_analyzer, sortable=True),
    filepath=ID(stored=True, unique=True),
    relative_path=STORED,
    modified=DATETIME(stored=True, sortable=True),
    size=STORED # File size in bytes
)

# --- Indexing Function ---
def create_or_update_index():
    """
    Creates or updates the Whoosh search index for files found in the ARCHIVE_ROOT directory.
    This version processes files directly without local copying, and efficiently checks for updates.
    Includes progress messages.
    """
    logging.info("Starting index creation/update process.")

    # 1. Initialize or Open Whoosh Index
    if not os.path.exists(WHOOSH_INDEX_DIR) or not exists_in(WHOOSH_INDEX_DIR):
        if not os.path.exists(WHOOSH_INDEX_DIR):
            os.makedirs(WHOOSH_INDEX_DIR)
            logging.info(f"Created Whoosh index directory: {WHOOSH_INDEX_DIR}")
        else:
            logging.warning(f"Directory {WHOOSH_INDEX_DIR} exists but does not contain a valid Whoosh index. Creating a new one.")

        ix = create_in(WHOOSH_INDEX_DIR, archive_schema)
        logging.info(f"Successfully created a new Whoosh index at: {WHOOSH_INDEX_DIR}")
    else:
        ix = open_dir(WHOOSH_INDEX_DIR)
        logging.info(f"Opening existing Whoosh index at: {WHOOSH_INDEX_DIR}")

    # 2. Prepare Index Writer
    writer = ix.writer(limitmb=512, multisegment=True) 
    
    # 3. Load Existing Indexed File Info for Efficient Comparison
    indexed_file_info = {}
    with ix.searcher() as searcher:
        for fields in searcher.all_stored_fields():
            indexed_file_info[fields['filepath']] = {
                'modified': fields['modified'],
                'size': fields['size']
            }
    logging.info(f"Found {len(indexed_file_info)} files previously indexed.")

    # 4. Scan Archive and Update Index
    current_file_paths_on_disk = set()
    num_indexed = 0
    num_updated = 0
    num_skipped = 0 

    total_files_scanned = 0
    # Adjust this interval based on how frequently you want updates (e.g., 1000 for smaller archives, 10000 for larger)
    progress_report_interval = 5000 

    logging.info(f"Starting to scan archive at: {ARCHIVE_ROOT}")
    start_scan_time = datetime.datetime.now() # Start timer for scanning phase
    
    for root, _, files in os.walk(ARCHIVE_ROOT):
        for filename in files:
            full_path = os.path.join(root, filename)

            try:
                # Ensure it's a file and accessible before attempting to stat
                if not os.path.isfile(full_path):
                    logging.debug(f"Skipping '{full_path}': Not a regular file or inaccessible.")
                    num_skipped += 1
                    total_files_scanned += 1 # Count even skipped items for progress
                    continue

                # Get current file metadata directly from the source path
                stat_info = os.stat(full_path)
                modified_date = datetime.datetime.fromtimestamp(stat_info.st_mtime)
                file_size_bytes = stat_info.st_size

                # Check if file is already indexed and up-to-date using in-memory data
                if full_path in indexed_file_info:
                    indexed_doc = indexed_file_info[full_path]
                    if indexed_doc['modified'] == modified_date and indexed_doc['size'] == file_size_bytes:
                        current_file_paths_on_disk.add(full_path) 
                        logging.debug(f"Skipping '{full_path}': Already indexed and up-to-date.")
                        num_skipped += 1
                        total_files_scanned += 1 # Count even skipped items for progress
                        continue 
                
                # If we reach here, the file needs to be indexed/updated
                current_file_paths_on_disk.add(full_path) 

                relative_path = os.path.relpath(full_path, ARCHIVE_ROOT)

                writer.update_document(
                    filename=filename,
                    filepath=full_path,
                    relative_path=relative_path,
                    modified=modified_date,
                    size=file_size_bytes
                )
                if full_path in indexed_file_info: 
                    logging.debug(f"Updated: '{full_path}'")
                    num_updated += 1
                else:
                    logging.debug(f"Indexed new file: '{full_path}'")
                    num_indexed += 1

            except FileNotFoundError:
                logging.warning(f"File not found during scan: '{full_path}'. Skipping.")
                num_skipped += 1
            except PermissionError:
                logging.warning(f"Permission denied for '{full_path}'. Skipping.")
                num_skipped += 1
            except OSError as e:
                logging.warning(f"OS Error when processing '{full_path}': {e}. Skipping.", exc_info=False)
                num_skipped += 1
            except Exception as e:
                logging.error(f"General error indexing '{full_path}': {e}. Skipping.", exc_info=True)
                num_skipped += 1
            
            # --- Progress Update Logic ---
            total_files_scanned += 1
            if total_files_scanned % progress_report_interval == 0:
                elapsed_time = datetime.datetime.now() - start_scan_time
                logging.info(f"Progress: Scanned {total_files_scanned} files. ({num_indexed} new, {num_updated} updated, {num_skipped} skipped). Elapsed: {elapsed_time}")

    end_scan_time = datetime.datetime.now() # End timer for scanning phase
    scan_duration = end_scan_time - start_scan_time
    logging.info(f"Finished scanning archive. Scanned {total_files_scanned} files in {scan_duration}.")
    logging.info(f"Summary: Indexed {num_indexed} new files, updated {num_updated} files, skipped {num_skipped} files during scan.")


    # 5. Remove Stale Files from Index
    files_to_remove = set(indexed_file_info.keys()) - current_file_paths_on_disk
    if files_to_remove:
        logging.info(f"Found {len(files_to_remove)} files to remove from index.")
        for path_to_remove in files_to_remove:
            writer.delete_by_term('filepath', path_to_remove)
            logging.info(f"Removed from index (file no longer exists): '{path_to_remove}'")
    else:
        logging.info("No files found for removal from index.")

    # 6. Commit Changes to Index
    commit_start_time = datetime.datetime.now()
    writer.commit()
    commit_duration = datetime.datetime.now() - commit_start_time
    logging.info(f"Indexing complete. Changes committed to index in {commit_duration}.")

if __name__ == '__main__':
    create_or_update_index()