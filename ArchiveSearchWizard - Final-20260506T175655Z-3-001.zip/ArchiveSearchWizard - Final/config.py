# config.py
# This file centralizes all major configuration settings for the Archive Search Wizard.
# Modify the values in this file to customize application behavior, file paths, and names.

import os

# --- Path Configuration ---
# These variables define the locations where your archive files are stored
# and where the search index will be created.
# They are critical for the application to function correctly.

# ARCHIVE_ROOT:
# This is the ABSOLUTE PATH to the top-level directory containing all your archive files.
# The application will scan this directory and all its subdirectories to build the search index.
#
# IMPORTANT CONSIDERATIONS:
# - Windows Paths: Use a 'raw string' prefix (r"...") to correctly handle backslashes (e.g., r"C:\My Documents\Archive").
#   Alternatively, use forward slashes (e.g., "C:/My Documents/Archive") or double backslashes ("C:\\My Documents\\Archive").
# - Network Shares: For network locations, use UNC paths (e.g., r"\\FileServer\DepartmentArchives").
# - Permissions: Ensure the user account running the 'index_archive.py' script AND the Flask application
#   (especially important for IIS deployment) has **READ access** to this directory and its contents.
#
# Example: r"D:\University_Records\Current_Archive"
# Example: r"\\networkdrive\shared_archive_data"
ARCHIVE_ROOT = r"\\UCOMM-FS1.ad.wsu.edu\Ucomm\Project Folders\Archive" # <<< --- REQUIRED: CHANGE THIS TO YOUR ACTUAL ARCHIVE ROOT PATH

# WHOOSH_INDEX_DIR:
# This is the ABSOLUTE PATH to the directory where the Whoosh search index files will be stored.
# This directory will be created automatically if it does not exist when the index is first built.
#
# IMPORTANT CONSIDERATIONS:
# - Permissions: Ensure the user account running the 'index_archive.py' script AND the Flask application
#   (especially for IIS deployment) has **READ and WRITE permissions** to this directory.
#   The index needs to be written to during indexing and read from during searches.
# - Location: It's generally recommended that this directory is NOT located inside your ARCHIVE_ROOT
#   to prevent accidentally trying to index the index files themselves, and for clearer separation.
# - Persistence: Choose a location that will not be inadvertently deleted or moved.
#
# Example: r"C:\Whoosh_Indexes\ArchiveSearchIndex"
# Example: "/var/www/search_app/whoosh_data" (for Linux/macOS deployments)
WHOOSH_INDEX_DIR = r"C:\Temp\SearchIndexes" # <<< --- REQUIRED: CHANGE THIS TO A SUITABLE AND PERSISTENT LOCATION FOR THE INDEX

# --- Application Settings ---
# These variables configure the general properties and branding of your search application.

# APP_NAME:
# This variable sets the display name of your search application.
# This name will appear in the web interface (e.g., in browser tab titles, page headings, and footers).
#
# You can change this to any descriptive name that suits your application's purpose.
# Example: "University Records Search"
# Example: "Departmental File Finder"
APP_NAME = "Archive Search Wizard" # <<< --- OPTIONAL: YOU CAN CHANGE THIS DISPLAY NAME