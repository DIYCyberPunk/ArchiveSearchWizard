# app.py
# This Flask application serves as a web-based search interface for a local file archive.
# It uses the Whoosh search library for indexing and searching files.

# --- Standard Library Imports ---
import os # For interacting with the operating system (e.g., file paths, directory checks)
import datetime # For handling dates and times (e.g., file modification dates)
import mimetypes # For guessing file types for downloads (e.g., 'application/pdf')
import logging # For logging application events, warnings, and errors

# --- Third-party Library Imports ---
# Flask: The web framework
from flask import Flask, render_template, request, send_from_directory, url_for, redirect, flash
# Whoosh: The search library components
from whoosh.index import open_dir, create_in, exists_in # For opening, creating, and checking index directory existence
from whoosh.fields import Schema, TEXT, ID, DATETIME, STORED, NUMERIC
from whoosh.qparser import QueryParser # For parsing user search queries
from whoosh.analysis import StandardAnalyzer, RegexTokenizer, LowercaseFilter # For defining how text is processed for indexing
from whoosh.query import Term
from whoosh import sorting # For defining sorting facets
from waitress import serve

# --- Application-specific Imports ---
# Import configuration settings from 'config.py'.
from config import ARCHIVE_ROOT, WHOOSH_INDEX_DIR, APP_NAME

# --- Flask App Initialization ---
app = Flask(__name__)

# IMPORTANT SECURITY SETTING: Flask Secret Key
app.config['SECRET_KEY'] = 'your_university_information_technology_team_really_loves_you_to_develop_this_secret_key_here' # <-- CHANGE THIS IN PRODUCTION!

# Context processor to inject the current year into all templates.
@app.context_processor
def inject_current_year():
    return {'current_year': datetime.datetime.now().year}

# --- Logging Setup ---
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s',
                    handlers=[
                        logging.FileHandler(os.path.join(os.path.dirname(__file__), 'app.log')),
                        logging.StreamHandler()
                    ])

# --- Whoosh Schema Definition ---
# IMPORTANT: This Schema MUST BE IDENTICAL to the one defined in index_archive.py.
my_simple_filename_analyzer = RegexTokenizer(r"\w+") | LowercaseFilter()

archive_schema = Schema(
    filename=TEXT(stored=True, analyzer=my_simple_filename_analyzer, sortable=True),
    filepath=ID(stored=True, unique=True),
    relative_path=STORED,
    modified=DATETIME(stored=True, sortable=True),
    # IMPORTANT FIX: This was changed to 'size=STORED' to match index_archive.py
    size=STORED 
)

# --- Helper Function: Converts bytes to human-readable size ---
def human_readable_size(size_bytes):
    """Converts a size in bytes to a human-readable string (e.g., 1.2 MB)."""
    # Handle non-numeric or zero/negative sizes gracefully
    if not isinstance(size_bytes, (int, float)) or size_bytes < 0:
        return "N/A"
    
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024**2:
        return f"{size_bytes / 1024:.2f} KB"
    elif size_bytes < 1024**3:
        return f"{size_bytes / (1024**2):.2f} MB"
    else:
        return f"{size_bytes / (1024**3):.2f} GB"

# --- Indexing Function (Generally run by index_archive.py) ---
# This function handles the logic for creating or updating the Whoosh search index.
# It's included for completeness or dev-time convenience but should be run by index_archive.py
def create_or_update_index():
    if not os.path.exists(WHOOSH_INDEX_DIR) or not exists_in(WHOOSH_INDEX_DIR):
        if not os.path.exists(WHOOSH_INDEX_DIR):
            os.makedirs(WHOOSH_INDEX_DIR)
            logging.info(f"Created Whoosh index directory: {WHOOSH_INDEX_DIR}")
        else:
            logging.warning(f"Directory {WHOOSH_INDEX_DIR} exists but does not contain a valid Whoosh index. Creating a new one.")

        ix = create_in(WHOOSH_INDEX_DIR, archive_schema)
        logging.info(f"Successfully created a new Whoosh index at: {WHOOSH_INDEX_DIR}")
    else:
        ix = open_dir(WHOOSH_INDEX_DIR)
        logging.info(f"Opening existing Whoosh index at: {WHOOSH_INDEX_DIR}")

    writer = ix.writer()
    indexed_file_paths = set()

    with ix.searcher() as searcher:
        for fields in searcher.all_stored_fields():
            indexed_file_paths.add(fields['filepath'])

    current_file_paths_on_disk = set()

    logging.info(f"Starting to scan archive at: {ARCHIVE_ROOT}")
    for root, _, files in os.walk(ARCHIVE_ROOT):
        for filename in files:
            full_path = os.path.join(root, filename)
            current_file_paths_on_disk.add(full_path)

            try:
                stat_info = os.stat(full_path)
                modified_date = datetime.datetime.fromtimestamp(stat_info.st_mtime)
                file_size_bytes = stat_info.st_size

                relative_path = os.path.relpath(full_path, ARCHIVE_ROOT)

                writer.update_document(
                    filename=filename,
                    filepath=full_path,
                    relative_path=relative_path,
                    modified=modified_date,
                    size=file_size_bytes 
                )
                logging.info(f"Indexed/Updated: {full_path}")

            except Exception as e:
                logging.error(f"Error indexing {full_path}: {e}", exc_info=True)

    files_to_remove = indexed_file_paths - current_file_paths_on_disk
    for path_to_remove in files_to_remove:
        writer.delete_by_term('filepath', path_to_remove)
        logging.info(f"Removed from index (file no longer exists): {path_to_remove}") 

    writer.commit()
    logging.info("Indexing complete.")


# --- Flask Routes ---
@app.route('/')
def index():
    return render_template('index.html', app_name=APP_NAME)

@app.route('/search', methods=['GET'])
def search():
    query_str = request.args.get('q', '').strip()
    sort_by = request.args.get('sort_by', 'score')
    sort_order = request.args.get('sort_order', 'asc')

    results = []
    error_message = None

    if not exists_in(WHOOSH_INDEX_DIR):
        error_message = "Search index not found or empty. Please run the indexing script."
        app.logger.warning(error_message)
    elif not query_str:
        pass
    else:
        # Re-indenting this entire try block to resolve potential SyntaxError related to indentation
        try: 
            ix = open_dir(WHOOSH_INDEX_DIR)
            with ix.searcher() as searcher:
                # This line was previously problematic, ensured it's correct now.
                query_parser = QueryParser("filename", ix.schema) 
                query = query_parser.parse(query_str)
                app.logger.info(f"Parsed search query: '{query_str}' into Whoosh query: '{query}'")
                print(f"Using QueryParser for search query: '{query_str}'")

                # Initialize sort_key_for_search to None (for default score sorting)
                sort_key_for_search = None
                # This flag controls the 'reverse' parameter of searcher.search
                search_level_reverse = False 

                if sort_by == 'filename':
                    # For FieldFacet, the 'reverse' argument is part of the Facet itself
                    sort_key_for_search = sorting.FieldFacet("filename", reverse=(sort_order == 'desc'))
                elif sort_by == 'modified':
                    sort_key_for_search = sorting.FieldFacet("modified", reverse=(sort_order == 'desc'))
                elif sort_by == 'size': 
                    sort_key_for_search = sorting.FieldFacet("size", reverse=(sort_order == 'desc'))
                elif sort_by == 'score':
                    # For score, let sortedby be None (default score sort).
                    # Only set search_level_reverse if we want ascending score.
                    if sort_order == 'asc':
                        search_level_reverse = True # True reverses the default descending score
                    # sort_key_for_search remains None here for score sorting
                else: # Fallback to score if an invalid sort_by is passed
                    if sort_order == 'asc':
                        search_level_reverse = True
                    # sort_key_for_search remains None here

                # Perform the search
                hits = searcher.search(query, limit=500, sortedby=sort_key_for_search, reverse=search_level_reverse)

                for hit in hits:
                    results.append({
                        'filename': hit['filename'],
                        'relative_path': hit['relative_path'],
                        'modified': hit['modified'].strftime('%Y-%m-%d %H:%M'),
                        'file_size': human_readable_size(hit['size']) 
                    })
                app.logger.info(f"Search for '{query_str}' found {len(results)} results.")

        except Exception as e:
            error_message = f"An error occurred during search: {e}"
            app.logger.error(f"Search error for '{query_str}': {e}", exc_info=True)
            flash(error_message, 'error')

    return render_template('search_results.html',
                            app_name=APP_NAME,
                            query=query_str,
                            results=results,
                            error_message=error_message,
                            sort_by=sort_by,
                            sort_order=sort_order)

@app.route('/download/<path:relative_file_path>')
def download_file(relative_file_path):
    """
    Handles secure file downloads from the archive.
    """
    try:
        full_path_on_disk = os.path.join(ARCHIVE_ROOT, relative_file_path)

        if not os.path.commonpath([os.path.abspath(ARCHIVE_ROOT), os.path.abspath(full_path_on_disk)]) == os.path.abspath(ARCHIVE_ROOT):
            logging.warning(f"Attempted directory traversal detected for path: {relative_file_path}")
            return "Unauthorized access or file not found.", 403

        if not os.path.exists(full_path_on_disk):
            logging.warning(f"File not found for download: {full_path_on_disk}")
            return "File not found.", 404

        directory = os.path.dirname(full_path_on_disk)
        filename = os.path.basename(full_path_on_disk)
        
        mimetype = mimetypes.guess_type(filename)[0] or 'application/octet-stream'

        logging.info(f"Initiating download for: {full_path_on_disk}")
        return send_from_directory(
            directory=directory,
            path=filename,
            as_attachment=True,
            mimetype=mimetype
        )
    except Exception as e:
        logging.error(f"Error during download for '{relative_file_path}': {e}", exc_info=True)
        return "An internal server error occurred during download.", 500

if __name__ == '__main__':
    # IMPORTANT FOR PRODUCTION:
    # Ensure create_or_update_index() is commented out when deploying as a service.
    # create_or_update_index() # Uncomment this line for convenient development indexing

    serve(app, host='0.0.0.0', port=5000)